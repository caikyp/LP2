﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            Double salBruto, numFilhos, aliINSS, aliIRPF, salFamilia, salLiquido, descIRPF, descINSS;

            if (Double.TryParse(mskbxSalBruto.Text, out salBruto) &&
                (txtNomeFunc.Text != "") &&
                Double.TryParse(txtNumFilhos.Text, out numFilhos))
            {
                    if (salBruto >= 0)
                    {
                        //verifica qual a aliquota INSS
                        if (salBruto <= 800.47)
                            aliINSS = 0.0765;
                        else if (salBruto <= 1050)
                            aliINSS = 0.0865;
                        else if (salBruto <= 1400.77)
                            aliINSS = 0.09;
                        else if (salBruto <= 2801.56)
                            aliINSS = 0.11;
                        else  
                            aliINSS = 0.11;                      
                        //calcula o desconto INSS
                        descINSS = salBruto * aliINSS;
                        aliINSS = aliINSS * 100;
                        //exibe a aliquota INSS
                        if (salBruto > 2801.56)
                        {
                            descINSS = 308.17;
                            txtAliqINSS.Text = "Teto";
                        } else
                            txtAliqINSS.Text = aliINSS.ToString("N2") + "%";
                        //exibe o desconto do INSS
                        txtDescINSS.Text = "R$"+descINSS.ToString("N2");

                        //verifica aliquota IRPF
                        if(salBruto <= 1257.12)
                            aliIRPF = 0;
                        else if (salBruto <= 2510.08)
                            aliIRPF = 0.15;
                        else
                            aliIRPF = 0.275;
                        //calcula o desconto IRPF
                        descIRPF = salBruto * aliIRPF;
                        aliIRPF = aliIRPF * 100;   
                        //exibe aliquota IRPF
                        if(aliIRPF == 0)
                            txtAliqIRPF.Text = "Isento";
                        else
                            txtAliqIRPF.Text = aliIRPF.ToString("n2") + "%";
                        //exibe desconto IRPF
                        txtDescIRPF.Text = "R$"+descIRPF.ToString("N2");

                        //verifica salario familia
                        if(salBruto <= 435.52)
                            salFamilia = 22.33 * numFilhos;
                        else if (salBruto <= 654.61)
                            salFamilia = 15.74 * numFilhos;
                        else
                            salFamilia = 0;
                        txtSalFamilia.Text = "R$" + salFamilia.ToString("N2");


                        //salario liquido
                        salLiquido = salBruto - descINSS - descIRPF + salFamilia;
                        txtSalLiquido.Text = "R$" + salLiquido.ToString("N2");

                        //mensagem label
                        if (rbtnF.Checked)
                            if (rbtnC.Checked)
                                lblInfo.Text = "A senhora " + txtNomeFunc.Text + ", casada e que possuí " + txtNumFilhos.Text + " filhos.";
                            else
                                lblInfo.Text = "A senhorita " + txtNomeFunc.Text + ", solteira e que possuí " + txtNumFilhos.Text + " filhos.";
                        else if (rbtnC.Checked)
                            lblInfo.Text = "O senhor " + txtNomeFunc.Text + ", casado e que possuí " + txtNumFilhos.Text + " filhos.";
                        else
                            lblInfo.Text = "O senhorito " + txtNomeFunc.Text + ", solteiro e que possuí " + txtNumFilhos.Text + " filhos.";

                }
                else
                    {
                        MessageBox.Show("O salário não pode ser 0 ou negativo");
                    }
            

            } else {
                MessageBox.Show("Nome ou salário estão errados. Conserte!");
                mskbxSalBruto.Clear();
                txtNomeFunc.Clear();
                txtNomeFunc.Focus();
            }
        }
    }
}
