﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic; // Project > Add References > Visual Basic    |  dps adiciona essa linha de codigo
using System.Collections;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            int lin = 40, col = 2;
            double[,] notas = new double[lin,col];
            double media1 = 0, media2 = 0;
            int i, j;

            for (i = 0; i < lin; i++)
            {
                for (j = 0; j < col; j++)
                {
                    auxiliar = Interaction.InputBox("Pessoa: " + (i + 1) + " - Digite a nota do filme: " + (j + 1));

                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else if (notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else if (j == 0)
                        media1 = media1 + notas[i, j];
                    else
                        media2 = media2 + notas[i, j];
                }
                lbxNotas.Items.Add("Pessoa: " + (i + 1) + " - Nota Filme 1: " + notas[i, j - 2].ToString("N2") + " Nota Filme 2: " + notas[i, j - 1].ToString("N2"));
            }
            media1 = media1 / i;
            media2 = media2 / i;

            lbxNotas.Items.Add("------------------------------");
            lbxNotas.Items.Add("Média Filme 1: " + media1.ToString("N2"));
            lbxNotas.Items.Add("Média Filme 2: " + media2.ToString("N2"));
            lbxNotas.Items.Add("------------------------------");
        }
    }
}
