﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInverteVetor = new System.Windows.Forms.Button();
            this.btnMercadoria = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnNomesPessoas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInverteVetor
            // 
            this.btnInverteVetor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInverteVetor.Location = new System.Drawing.Point(115, 63);
            this.btnInverteVetor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnInverteVetor.Name = "btnInverteVetor";
            this.btnInverteVetor.Size = new System.Drawing.Size(197, 117);
            this.btnInverteVetor.TabIndex = 0;
            this.btnInverteVetor.Text = "Carrega Vetor e Inverte ";
            this.btnInverteVetor.UseVisualStyleBackColor = true;
            this.btnInverteVetor.Click += new System.EventHandler(this.btnInverteVetor_Click);
            // 
            // btnMercadoria
            // 
            this.btnMercadoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMercadoria.Location = new System.Drawing.Point(364, 63);
            this.btnMercadoria.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMercadoria.Name = "btnMercadoria";
            this.btnMercadoria.Size = new System.Drawing.Size(197, 117);
            this.btnMercadoria.TabIndex = 1;
            this.btnMercadoria.Text = "Ler Dados Mercadoria";
            this.btnMercadoria.UseVisualStyleBackColor = true;
            this.btnMercadoria.Click += new System.EventHandler(this.btnMercadoria_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotal.Location = new System.Drawing.Point(599, 64);
            this.btnTotal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(197, 117);
            this.btnTotal.TabIndex = 2;
            this.btnTotal.Text = "Verificar Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrayList.Location = new System.Drawing.Point(115, 222);
            this.btnArrayList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(197, 117);
            this.btnArrayList.TabIndex = 3;
            this.btnArrayList.Text = "ArrayList";
            this.btnArrayList.UseVisualStyleBackColor = true;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedia.Location = new System.Drawing.Point(364, 222);
            this.btnMedia.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(197, 117);
            this.btnMedia.TabIndex = 4;
            this.btnMedia.Text = "Media Alunos";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnNomesPessoas
            // 
            this.btnNomesPessoas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNomesPessoas.Location = new System.Drawing.Point(599, 222);
            this.btnNomesPessoas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNomesPessoas.Name = "btnNomesPessoas";
            this.btnNomesPessoas.Size = new System.Drawing.Size(197, 117);
            this.btnNomesPessoas.TabIndex = 5;
            this.btnNomesPessoas.Text = "Nomes Pessoas";
            this.btnNomesPessoas.UseVisualStyleBackColor = true;
            this.btnNomesPessoas.Click += new System.EventHandler(this.btnNomesPessoas_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 513);
            this.Controls.Add(this.btnNomesPessoas);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnTotal);
            this.Controls.Add(this.btnMercadoria);
            this.Controls.Add(this.btnInverteVetor);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInverteVetor;
        private System.Windows.Forms.Button btnMercadoria;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnNomesPessoas;
    }
}

