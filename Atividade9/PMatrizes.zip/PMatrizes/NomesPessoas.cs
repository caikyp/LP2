﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic; // Project > Add References > Visual Basic    |  dps adiciona essa linha de codigo


namespace PMatrizes
{
    public partial class NomesPessoas : Form
    {
        public NomesPessoas()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
           
            string[] nomes = new string[4];
            int[] tamanho = new int[4];
            string auxiliar = "";

            for (int i = 0; i < nomes.Length; i++) {
                auxiliar = Interaction.InputBox("Digite o nome completo: ", "Entrada de Dados");

                if (auxiliar == "0") //parar o programa se digitar 0
                    break;
                else if (auxiliar != "") {
                    nomes[i] = auxiliar;
                    auxiliar = nomes[i].Replace(" ", "");
                    tamanho[i] = auxiliar.Length;

                    lbxNomes.Items.Add("O nome: " + nomes[i] + " tem " + tamanho[i] +
                        " caracteres\n");
                } else {
                    MessageBox.Show("Valor invalido");
                    i--;
                }

            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxNomes.Items.Clear();
        }
    }
}

