﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtA.Focus();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double a, b, c;

            if (double.TryParse(txtA.Text, out a) && 
                double.TryParse(txtB.Text, out b) && 
                double.TryParse(txtC.Text, out c)) {

                if((a < b+c && a > Math.Abs(b-c))|| 
                    (b < a+c && b > Math.Abs(a-c))||
                    (c < a+b && c > Math.Abs(a-b))) {
                    if (a == b && a == c) {
                        MessageBox.Show("Triangulo Equilatero");
                    } else if (a == b || a == c || b == c) {
                        MessageBox.Show("Triangulo Isosceles");
                    } else {
                        MessageBox.Show("Triangulo Escaleno");
                    }

                } else {
                    MessageBox.Show("Não é um triangulo");
                }
            } else {
                MessageBox.Show("Valores inválidos");
                txtA.Clear();
                txtB.Clear();
                txtC.Clear();
                txtA.Focus();
            }
        }
    }
}
