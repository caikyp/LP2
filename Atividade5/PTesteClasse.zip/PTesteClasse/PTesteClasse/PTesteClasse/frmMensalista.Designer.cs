﻿namespace PTesteClasse
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.lblDataEntEmpresa = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.txtDataEntEmpresa = new System.Windows.Forms.TextBox();
            this.gbxHome = new System.Windows.Forms.GroupBox();
            this.rBtnNao = new System.Windows.Forms.RadioButton();
            this.rBtnSim = new System.Windows.Forms.RadioButton();
            this.btnInstacMensalista = new System.Windows.Forms.Button();
            this.btnInstancMensPar = new System.Windows.Forms.Button();
            this.gbxHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.Location = new System.Drawing.Point(105, 90);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(77, 18);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(105, 137);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(53, 18);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioMensal.Location = new System.Drawing.Point(105, 183);
            this.lblSalarioMensal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(120, 18);
            this.lblSalarioMensal.TabIndex = 2;
            this.lblSalarioMensal.Text = "Salário Mensal";
            // 
            // lblDataEntEmpresa
            // 
            this.lblDataEntEmpresa.AutoSize = true;
            this.lblDataEntEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataEntEmpresa.Location = new System.Drawing.Point(105, 241);
            this.lblDataEntEmpresa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDataEntEmpresa.Name = "lblDataEntEmpresa";
            this.lblDataEntEmpresa.Size = new System.Drawing.Size(178, 18);
            this.lblDataEntEmpresa.TabIndex = 3;
            this.lblDataEntEmpresa.Text = "Data Entrada Empresa";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatricula.Location = new System.Drawing.Point(328, 81);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(151, 24);
            this.txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(328, 129);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(301, 24);
            this.txtNome.TabIndex = 5;
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioMensal.Location = new System.Drawing.Point(328, 175);
            this.txtSalarioMensal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(151, 24);
            this.txtSalarioMensal.TabIndex = 6;
            // 
            // txtDataEntEmpresa
            // 
            this.txtDataEntEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDataEntEmpresa.Location = new System.Drawing.Point(328, 234);
            this.txtDataEntEmpresa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDataEntEmpresa.Name = "txtDataEntEmpresa";
            this.txtDataEntEmpresa.Size = new System.Drawing.Size(151, 24);
            this.txtDataEntEmpresa.TabIndex = 7;
            // 
            // gbxHome
            // 
            this.gbxHome.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbxHome.Controls.Add(this.rBtnNao);
            this.gbxHome.Controls.Add(this.rBtnSim);
            this.gbxHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxHome.Location = new System.Drawing.Point(744, 80);
            this.gbxHome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxHome.Name = "gbxHome";
            this.gbxHome.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxHome.Size = new System.Drawing.Size(220, 180);
            this.gbxHome.TabIndex = 8;
            this.gbxHome.TabStop = false;
            this.gbxHome.Text = "Trabalha em Home Office?";
            // 
            // rBtnNao
            // 
            this.rBtnNao.AutoSize = true;
            this.rBtnNao.Checked = true;
            this.rBtnNao.Location = new System.Drawing.Point(23, 103);
            this.rBtnNao.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rBtnNao.Name = "rBtnNao";
            this.rBtnNao.Size = new System.Drawing.Size(63, 24);
            this.rBtnNao.TabIndex = 1;
            this.rBtnNao.TabStop = true;
            this.rBtnNao.Text = "Não";
            this.rBtnNao.UseVisualStyleBackColor = true;
            this.rBtnNao.CheckedChanged += new System.EventHandler(this.rdBtnNao_CheckedChanged);
            // 
            // rBtnSim
            // 
            this.rBtnSim.AutoSize = true;
            this.rBtnSim.Location = new System.Drawing.Point(23, 57);
            this.rBtnSim.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rBtnSim.Name = "rBtnSim";
            this.rBtnSim.Size = new System.Drawing.Size(62, 24);
            this.rBtnSim.TabIndex = 0;
            this.rBtnSim.Text = "Sim";
            this.rBtnSim.UseVisualStyleBackColor = true;
            // 
            // btnInstacMensalista
            // 
            this.btnInstacMensalista.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstacMensalista.Location = new System.Drawing.Point(76, 352);
            this.btnInstacMensalista.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnInstacMensalista.Name = "btnInstacMensalista";
            this.btnInstacMensalista.Size = new System.Drawing.Size(255, 103);
            this.btnInstacMensalista.TabIndex = 9;
            this.btnInstacMensalista.Text = "Instanciar Mensalista";
            this.btnInstacMensalista.UseVisualStyleBackColor = true;
            this.btnInstacMensalista.Click += new System.EventHandler(this.btnInstacMensalista_Click);
            // 
            // btnInstancMensPar
            // 
            this.btnInstancMensPar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstancMensPar.Location = new System.Drawing.Point(493, 352);
            this.btnInstancMensPar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnInstancMensPar.Name = "btnInstancMensPar";
            this.btnInstancMensPar.Size = new System.Drawing.Size(255, 103);
            this.btnInstancMensPar.TabIndex = 10;
            this.btnInstancMensPar.Text = "Instanciar Mensalista passando parâmetros";
            this.btnInstancMensPar.UseVisualStyleBackColor = true;
            this.btnInstancMensPar.Click += new System.EventHandler(this.btnInstancMensPar_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 551);
            this.Controls.Add(this.btnInstancMensPar);
            this.Controls.Add(this.btnInstacMensalista);
            this.Controls.Add(this.gbxHome);
            this.Controls.Add(this.txtDataEntEmpresa);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblDataEntEmpresa);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.gbxHome.ResumeLayout(false);
            this.gbxHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.Label lblDataEntEmpresa;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.TextBox txtDataEntEmpresa;
        private System.Windows.Forms.GroupBox gbxHome;
        private System.Windows.Forms.RadioButton rBtnNao;
        private System.Windows.Forms.RadioButton rBtnSim;
        private System.Windows.Forms.Button btnInstacMensalista;
        private System.Windows.Forms.Button btnInstancMensPar;
    }
}