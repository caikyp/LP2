﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasse
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void frmHorista_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnInstancHorista_Click(object sender, EventArgs e)
        {
            //Instanciando o objeto da classe Horista

            Horista objHorista = new Horista();

            //set

            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntEmpresa.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalarioHora.Text);

            if (rbtnSim.Checked)
            {
                objHorista.HomeOffice = 'S';
            }
            else
            {
                objHorista.HomeOffice = 'N';
            }

            objHorista.NumeroHora = Convert.ToDouble(txtHoras.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFalta.Text);

            //get

            MessageBox.Show("Matricula: " + objHorista.Matricula + "\n" +
                            "Nome: " + objHorista.NomeEmpregado + "\n" +
                            "Data Entrada: " + objHorista.DataEntradaEmpresa.ToShortDateString() + "\n" +
                            "Salario Bruto: " + objHorista.SalarioBruto().ToString("N2") + "\n" +
                            "Tempre Empresa (Dias): " + objHorista.TempoTrabalho() + "\n" +
                            objHorista.VerificaHome());


        }
    }
}
