﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rctbxTexto = new System.Windows.Forms.RichTextBox();
            this.btnNumerico = new System.Windows.Forms.Button();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnAlfabetico = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rctbxTexto
            // 
            this.rctbxTexto.Location = new System.Drawing.Point(104, 70);
            this.rctbxTexto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rctbxTexto.Name = "rctbxTexto";
            this.rctbxTexto.Size = new System.Drawing.Size(676, 160);
            this.rctbxTexto.TabIndex = 0;
            this.rctbxTexto.Text = "";
            // 
            // btnNumerico
            // 
            this.btnNumerico.Location = new System.Drawing.Point(104, 273);
            this.btnNumerico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNumerico.Name = "btnNumerico";
            this.btnNumerico.Size = new System.Drawing.Size(169, 80);
            this.btnNumerico.TabIndex = 1;
            this.btnNumerico.Text = "Numérico";
            this.btnNumerico.UseVisualStyleBackColor = true;
            this.btnNumerico.Click += new System.EventHandler(this.btnNumerico_Click);
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(364, 273);
            this.btnEspaco.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(169, 80);
            this.btnEspaco.TabIndex = 2;
            this.btnEspaco.Text = "Primeiro Espaço em Branco";
            this.btnEspaco.UseVisualStyleBackColor = true;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click);
            // 
            // btnAlfabetico
            // 
            this.btnAlfabetico.Location = new System.Drawing.Point(612, 273);
            this.btnAlfabetico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAlfabetico.Name = "btnAlfabetico";
            this.btnAlfabetico.Size = new System.Drawing.Size(169, 80);
            this.btnAlfabetico.TabIndex = 3;
            this.btnAlfabetico.Text = "Alfabético";
            this.btnAlfabetico.UseVisualStyleBackColor = true;
            this.btnAlfabetico.Click += new System.EventHandler(this.btnAlfabetico_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 462);
            this.Controls.Add(this.btnAlfabetico);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.btnNumerico);
            this.Controls.Add(this.rctbxTexto);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rctbxTexto;
        private System.Windows.Forms.Button btnNumerico;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnAlfabetico;
    }
}